//------------------------------------------------------------------------------
//  Copyright(C) ASRC, 2013-2016. All rights reserved.
//------------------------------------------------------------------------------
//  Project    : TBD
//  Description: DRMP Application Entry
//  Author     : Fu Pengfei
//------------------------------------------------------------------------------
//  Change Logs:
//  Date         Notes
//  2015-07-29   first implementation
//------------------------------------------------------------------------------
//  $Id:: main.c 1119 2015-10-07 09:11:14Z arda                                $
//------------------------------------------------------------------------------
#include <rtthread.h>
int rtthread_startup(void);
int main(void)
{
  /* user app entry */
	//rtthread_startup();
	//return 0;
}
